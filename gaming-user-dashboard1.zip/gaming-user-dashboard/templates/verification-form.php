<?php
/**
 * Verification form template.
 *
 * @var array $form_data
 */

defined( 'ABSPATH' ) || exit;

$status_class_map = array(
	'pending'  => 'gud-status-pending',
	'approved' => 'gud-status-approved',
	'rejected' => 'gud-status-rejected',
	'none'     => 'gud-status-none',
);
$status_class = isset( $status_class_map[ $form_data['status'] ] ) ? $status_class_map[ $form_data['status'] ] : $status_class_map['none'];
?>
<div class="gud-section-title"><?php echo esc_html__( 'فرم احراز هویت', 'gaming-user-dashboard' ); ?></div>

<?php if ( 'none' !== $form_data['status'] ) : ?>
	<div class="gud-status-banner <?php echo esc_attr( $status_class ); ?>">
		<span class="gud-status-dot" aria-hidden="true"></span>
		<strong><?php echo esc_html__( 'وضعیت:', 'gaming-user-dashboard' ); ?></strong>
		<span><?php echo esc_html( $form_data['status_label'] ); ?></span>
	</div>
<?php endif; ?>

<?php if ( 'rejected' === $form_data['status'] && ! empty( $form_data['rejection_reason'] ) ) : ?>
	<div class="gud-status-reason">
		<strong><?php echo esc_html__( 'دلیل رد شدن:', 'gaming-user-dashboard' ); ?></strong>
		<span><?php echo esc_html( $form_data['rejection_reason'] ); ?></span>
	</div>
<?php endif; ?>

<form method="post" class="gud-form gud-verification-form" novalidate enctype="multipart/form-data" data-gud-verify-form data-gud-editable="<?php echo $form_data['is_editable'] ? '1' : '0'; ?>">
	<?php wp_nonce_field( 'gud_verify_identity_action', 'gud_verify_identity_nonce' ); ?>
	<input type="hidden" name="gud_verify_identity" value="1" />

	<div class="gud-verify-grid" role="group" aria-label="<?php echo esc_attr__( 'فرم احراز هویت', 'gaming-user-dashboard' ); ?>">
		<div class="gud-verify-row">
			<div class="gud-form-row">
				<label for="gud_full_name"><?php echo esc_html__( 'نام و نام خانوادگی', 'gaming-user-dashboard' ); ?> <span class="gud-help" data-gud-tooltip="<?php echo esc_attr__( 'حداقل دو کلمه (نام و نام خانوادگی) با فاصله و هر کلمه حداقل ۳ حرف.', 'gaming-user-dashboard' ); ?>">?</span></label>
				<input id="gud_full_name" name="gud_full_name" type="text" value="<?php echo esc_attr( $form_data['full_name'] ); ?>" <?php disabled( ! $form_data['is_editable'] ); ?> required maxlength="120" data-gud-validate="full-name" />
				<small class="gud-field-feedback" data-gud-feedback-for="gud_full_name"></small>
			</div>

			<div class="gud-form-row">
				<label for="gud_mobile"><?php echo esc_html__( 'شماره موبایل', 'gaming-user-dashboard' ); ?> <span class="gud-help" data-gud-tooltip="<?php echo esc_attr__( 'شماره باید با 09 شروع شود و 11 رقم باشد.', 'gaming-user-dashboard' ); ?>">?</span></label>
				<input id="gud_mobile" name="gud_mobile" type="tel" dir="ltr" pattern="09[0-9]{9}" value="<?php echo esc_attr( $form_data['mobile'] ); ?>" <?php echo $form_data['mobile_locked'] ? 'readonly aria-readonly="true"' : ''; ?> <?php disabled( ! $form_data['is_editable'] && $form_data['mobile_locked'] ); ?> required data-gud-validate="mobile" />
				<small class="gud-field-feedback" data-gud-feedback-for="gud_mobile"></small>
			</div>
		</div>

		<div class="gud-verify-row">
			<div class="gud-form-row gud-upload-card">
				<label for="gud_id_cards"><?php echo esc_html__( 'آپلود عکس پشت و روی کارت ملی', 'gaming-user-dashboard' ); ?> <span class="gud-help" data-gud-tooltip="<?php echo esc_attr__( 'فقط دو تصویر (پشت و رو) بارگذاری کنید؛ هر کدام حداکثر ۵ مگابایت.', 'gaming-user-dashboard' ); ?>">?</span></label>
				<input id="gud_id_cards" name="gud_id_cards[]" type="file" accept="image/jpeg,image/png,image/webp" multiple <?php disabled( ! $form_data['is_editable'] ); ?> <?php echo $form_data['is_editable'] ? 'required' : ''; ?> data-gud-max-files="2" />
				<small class="gud-field-feedback" data-gud-feedback-for="gud_id_cards"></small>
				<?php if ( ! empty( $form_data['id_card_ids'] ) ) : ?>
					<div class="gud-existing-images">
						<?php foreach ( $form_data['id_card_ids'] as $card_id ) : ?>
							<?php echo wp_kses_post( wp_get_attachment_image( absint( $card_id ), 'thumbnail' ) ); ?>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
			<div class="gud-form-row gud-upload-card">
				<label for="gud_pledge_file"><?php echo esc_html__( 'آپلود عکس تعهدنامه', 'gaming-user-dashboard' ); ?> <span class="gud-help" data-gud-tooltip="<?php echo esc_attr__( 'تعهدنامه امضا شده و همراه با تاریخ روز باشد.', 'gaming-user-dashboard' ); ?>">?</span> <button class="gud-inline-link" type="button" data-gud-modal-open="pledge-text"><?php echo esc_html__( 'متن تعهدنامه', 'gaming-user-dashboard' ); ?></button></label>
				<input id="gud_pledge_file" name="gud_pledge_file" type="file" accept="image/jpeg,image/png,image/webp" <?php disabled( ! $form_data['is_editable'] ); ?> <?php echo $form_data['is_editable'] ? 'required' : ''; ?> />
				<small class="gud-field-feedback" data-gud-feedback-for="gud_pledge_file"></small>
				<?php if ( ! empty( $form_data['pledge_id'] ) ) : ?>
					<div class="gud-existing-images"><?php echo wp_kses_post( wp_get_attachment_image( absint( $form_data['pledge_id'] ), 'thumbnail' ) ); ?></div>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<div class="gud-form-row gud-submit-row">
		<button type="submit" class="gud-btn gud-btn-primary" data-gud-submit <?php disabled( ! $form_data['is_editable'] ); ?>><?php echo esc_html__( 'ارسال', 'gaming-user-dashboard' ); ?></button>
		<label class="gud-rules-check" for="gud_accept_rules">
			<input id="gud_accept_rules" name="gud_accept_rules" type="checkbox" value="1" <?php checked( ! empty( $form_data['rules_accepted'] ) ); ?> <?php disabled( ! $form_data['is_editable'] ); ?> <?php echo $form_data['is_editable'] ? 'required' : ''; ?> data-gud-rules />
			<span><?php echo esc_html__( 'قبول قوانین سایت', 'gaming-user-dashboard' ); ?></span>
			<button class="gud-inline-link" type="button" data-gud-modal-open="rules-text"><?php echo esc_html__( 'مشاهده قوانین', 'gaming-user-dashboard' ); ?></button>
		</label>
		<small class="gud-field-feedback" data-gud-feedback-for="gud_accept_rules"></small>
	</div>
</form>

<div class="gud-modal" id="gud-modal-pledge-text" aria-hidden="true" role="dialog" aria-modal="true">
	<div class="gud-modal-dialog">
		<button type="button" class="gud-modal-close" data-gud-modal-close>&times;</button>
		<h3><?php echo esc_html__( 'متن تعهدنامه', 'gaming-user-dashboard' ); ?></h3>
		<p>
			<?php echo esc_html__( 'اینجانب ……………………………، فرزند ……………………………، به شماره ملی …………………………… و شماره تماس ……………………………، با آگاهی کامل، با اراده و اختیار شخصی، بدین‌وسیله متعهد می‌شوم:', 'gaming-user-dashboard' ); ?><br><br>
			<?php echo esc_html__( 'کلیه اطلاعات ارائه‌شده توسط اینجانب در فرم احراز هویت، به‌صورت کامل، صحیح و واقعی می‌باشد و هیچ‌گونه جعل، مخفی‌کاری یا اطلاعات نادرست ارائه نکرده‌ام.', 'gaming-user-dashboard' ); ?><br>
			<?php echo esc_html__( 'تمامی اکانت‌هایی که از طریق سایت «gamebani.ir» برای فروش ثبت می‌کنم، متعلق به شخص خودم بوده و مالکیت کامل، دائمی و قانونی آن‌ها را دارم. فروش اکانت‌های متعلق به دیگران، اجاره‌ای، اشتراکی، هک‌شده یا دارای مشکلات حقوقی، تحت هیچ شرایطی انجام نخواهم داد.', 'gaming-user-dashboard' ); ?><br>
			<?php echo esc_html__( 'در صورت بروز هرگونه مشکل، شکایت، بازپس‌گیری اکانت، فریب خریدار، یا تخلف از قوانین سایت، مسئولیت کامل حقوقی، کیفری و مالی آن بر عهده شخص اینجانب می‌باشد، و سایت «gamebani.ir» هیچ‌گونه مسئولیتی در این خصوص ندارد.', 'gaming-user-dashboard' ); ?><br>
			<?php echo esc_html__( 'اینجانب می‌دانم که طبق ماده 740 قانون مجازات اسلامی و قوانین تجارت الکترونیک کشور، هرگونه فریب، کلاهبرداری، جعل هویت یا نقض حقوق کاربران، جرم محسوب شده و پیگرد قانونی دارد.', 'gaming-user-dashboard' ); ?><br>
			<?php echo esc_html__( 'همچنین اینجانب می‌پذیرم که در صورت تخلف، سایت «gamebani.ir» مجاز است حساب کاربری مرا مسدود کرده و اطلاعات مرا جهت پیگیری قضایی در اختیار مراجع ذی‌صلاح قرار دهد.', 'gaming-user-dashboard' ); ?><br>
			<?php echo esc_html__( 'تاریخ تنظیم: ………………', 'gaming-user-dashboard' ); ?><br>
			<?php echo esc_html__( 'امضاء و اثر انگشت', 'gaming-user-dashboard' ); ?>
		</p>
		<a class="gud-download-btn" href="<?php echo esc_url( plugins_url( 'assets/docs/gud-pledge-a4.html', dirname( __FILE__ ) ) ); ?>" target="_blank" rel="noopener" download><?php echo esc_html__( 'دانلود نسخه چاپی A4 تعهدنامه', 'gaming-user-dashboard' ); ?></a>
		<p class="gud-pledge-help"><?php echo esc_html__( 'فایل را چاپ کنید، بخش‌های خالی را با خودکار تکمیل کرده و از برگه کامل‌شده عکس گرفته و در قسمت آپلود تعهدنامه ارسال کنید.', 'gaming-user-dashboard' ); ?></p>
	</div>
</div>

<div class="gud-modal" id="gud-modal-rules-text" aria-hidden="true" role="dialog" aria-modal="true">
	<div class="gud-modal-dialog">
		<button type="button" class="gud-modal-close" data-gud-modal-close>&times;</button>
		<h3><?php echo esc_html__( 'قوانین سایت', 'gaming-user-dashboard' ); ?></h3>
		<p><?php echo esc_html__( 'با ثبت این فرم، صحت اطلاعات را تایید کرده و با سیاست‌های حفظ حریم خصوصی و قوانین استفاده از خدمات موافقت می‌کنم.', 'gaming-user-dashboard' ); ?></p>
	</div>
</div>
